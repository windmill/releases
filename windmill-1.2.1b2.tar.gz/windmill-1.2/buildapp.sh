rm -rf build dist ; python build_setup.py py2app
