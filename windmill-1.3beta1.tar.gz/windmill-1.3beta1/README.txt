Windmill is currently a very active work-in-progress so the best place
to find up-to-date information would be online:

  http://trac.getwindmill.com/#Documentation

Another great location is the mailing list:

  http://groups.google.com/group/windmill-dev

You can check build status at:

  http://avocado.monkeypox.org/view/Windmill%20Jobs/

